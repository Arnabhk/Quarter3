#pragma once
#include "Generators.h"
#include "Helpers.h"

using namespace std;

void Question3();
