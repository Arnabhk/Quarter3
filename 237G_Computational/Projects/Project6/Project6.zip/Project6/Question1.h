#pragma once
#include "Helpers.h"
#include "Generators.h"

using namespace std;

void Question1();
