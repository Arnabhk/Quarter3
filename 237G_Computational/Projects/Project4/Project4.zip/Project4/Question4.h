#pragma once
#include "Generators.h"
#include "Helpers.h"

using namespace std;

void Question4();
double PartcAmer(double r, double delta, double sigma, int noOfSteps, double s0, double k, char optionType = 'c');