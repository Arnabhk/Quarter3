import Final_1
import Final_2
import Final_3
import Final_4
import Final_5

# Question 1
Final_1.question1()

# Question 2
Final_2.question2()

# Question 3
Final_3.question3()

# Question 4
Final_4.question4()

# Question 5
Final_5.question5()