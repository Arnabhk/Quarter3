#include "Question1.h"
#include "Question2.h"

#include <iostream>
using namespace std;

int main()
{
	cout << "###########################################" << endl;
	cout << "Computational Finance Problem Set 6" << endl;
	cout << "Nitish Ramkumar" << endl;
	cout << "###########################################" << endl;
	
	//Question 1
	cout << endl << "QUESTION 1" << endl;
	Question1();

	//Question 2
	cout << endl << "QUESTION 2" << endl;
	Proj6_2func();

	int dummy;
	cout << endl << endl << "Press a key to close";
	dummy = getchar();

}

